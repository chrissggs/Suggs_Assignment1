
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * Christopher Suggs */
public class List {
     public static void main(String[] args)
    {
        Scanner scarface = new Scanner(System.in);   
     
//        linkedStack ls = new linkedStack();          
        
        System.out.println("Create a linked stack");  
        char ch;     
        do 
        {
            System.out.println("What would you like to do with the stacks?");
            System.out.println("1. push integer into stack");
            System.out.println("2. pop integer in stack");
            System.out.println("3. display stack contents");
            System.out.println("4. check if stack is empty");
            System.out.println("5. check stack size");            
            int choice = scarface.nextInt();
            switch (choice) 
            {
            case 1 :
                System.out.println("Enter integer to push");
                ls.push( scarface.nextInt() ); 
                break;                         
            case 2 : 
                try
                {
                    System.out.println("Popped Integer = "+ ls.pop());
                }
                catch (Exception e)
                {
                    System.out.println("Error : " + e.getMessage());
                }    
                break;                         
            case 3 : 
                try
                {
                    System.out.println("Peek Element = "+ ls.peek());
                }
                catch (Exception e)
                {
                    System.out.println("Error : " + e.getMessage());
                }
                break;                         
            case 4 : 
                System.out.println("Empty status = "+ ls.isEmpty());
                break;                
            case 5 : 
                System.out.println("Size = "+ ls.getSize()); 
                break;                
            case 6 : 
                System.out.println("Stack = "); 
                ls.display();
                break;                        
            default : 
                System.out.println("You must enter a number 1 through 6. ");
                break;
            }           
            /* display stack */    
            ls.display();            
            System.out.println("\nDo you want to continue (Type y or n) \n");
            ch = scan.next().charAt(0);       

        } while (ch == 'Y'|| ch == 'y');                 
    }
}

